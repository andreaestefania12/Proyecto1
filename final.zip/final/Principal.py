from tkinter import *
#Crear ventana Principal
ventana=Tk()
ventana.title("Pinball Andrea Timaran")
canvas=Canvas(ventana, width=1000, height=600)
fondo = PhotoImage(file="1.gif")
canvas.create_image(450,300,image=fondo)
foto = PhotoImage(file="final.gif")
canvas.create_image(500,300,image=foto)
canvas.pack()


def quitar(ventana):
    ventana.destroy()

def funcion():
    quitar(ventana)
    import Final
    
def informacion():
    quitar(ventana)
    import informacion

#Crear botones ventana principal
boton=PhotoImage(file="boton4.png")
boton1=PhotoImage(file="boton3.png")
boton2=PhotoImage(file="boton1.png")

botonJugar=Button(ventana, width=170,command=funcion,bg="#A9E2F3",image=boton).place(x=150,y=380)
botonSalir=Button(ventana, width=170,command=ventana.destroy,bg="#A9E2F3",image=boton2).place(x=400,y=380)
botonInfo=Button(ventana,width=170,command=informacion,bg="#A9E2F3",image=boton1).place(x=270,y=470)
ventana.mainloop()


    

    
