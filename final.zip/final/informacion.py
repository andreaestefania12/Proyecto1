from tkinter import *

#Creando vent2 Información
vent2=Tk()
vent2.title("Pinball Andrea Timaran")
canv2=Canvas(vent2, width=1000, height=600)
fondo = PhotoImage(file="1.gif")
canv2.create_image(450,300,image=fondo)

#Información
infol=canv2.create_text(130,60,text="Objetivo",font=("Barbieri-Book",20),fill="yellow")
info=canv2.create_text(400,120,text="Conseguir la mayor cantidad de puntos antes de que\nla bola caiga al fondo", font=("Barbieri-Book",20),fill="white")

#Reglas
reglas=canv2.create_text(123,190,text="Reglas",font=("Barbieri-Book",20),fill="yellow")
rg1=canv2.create_text(250,230,text="El jugador inicia con 1 vida",font=("Barbieri-Book",20),fill="white")
rg2=canv2.create_text(465,270,text="El jugador pierde una vida cada vez que la pelota caiga al fondo",font=("Barbieri-Book",20),fill="white")

#Teclas
teclas=canv2.create_text(155,320,text="Teclas a usar",font=("Barbieri-Book",20),fill="yellow")
tc1=canv2.create_text(360,350,text="Para iniciar el juego presionar la tecla 'espacio'",font=("Barbieri-Book",20),fill="white")
tc2=canv2.create_text(295,380,text="Para la paleta izquierda presionar 'a'",font=("Barbieri-Book",20),fill="white")
tc3=canv2.create_text(342,410,text="Para la paleta derecha presionar la tecla 'up'",font=("Barbieri-Book",20),fill="white")

#imagenes0

imagen= PhotoImage(file="tecla.png")

canv2.create_image(800,400,image=imagen)
imagen2= PhotoImage(file="espacio.png")
canv2.create_image(800,350,image=imagen2)
imagen3= PhotoImage(file="a.png")
canv2.create_image(700,380,image=imagen3)


canv2.pack()
boton = PhotoImage(file="boton5.png")

def quitar(vent2):
    vent2.destroy()

def menu():
    quitar(vent2)
    import Principal

botonMenu=Button(vent2, text="Regresar al menú",font=("Baribieri-Book",22),width=170,command=menu,bg="#A9E2F3",image=boton).place(x=370,y=470)
vent2.mainloop()
